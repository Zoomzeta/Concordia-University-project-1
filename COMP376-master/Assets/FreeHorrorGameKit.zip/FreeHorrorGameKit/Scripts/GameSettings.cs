﻿public class GameSettings
{
    public bool fullscren;
    public int textureQuality;
    public int antialiasing;
    public int vSync;
    public int resolutionsIndex;
    public float musicVolume;
}
